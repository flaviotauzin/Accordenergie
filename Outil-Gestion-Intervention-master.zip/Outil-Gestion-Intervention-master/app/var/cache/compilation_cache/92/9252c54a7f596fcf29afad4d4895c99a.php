<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* register.html.twig */
class __TwigTemplate_0f5d133dec4abe7522e07d7703b7a89e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\"/>
    <title>AccordEnergie</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f0f0;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 90vh;
            background-image: linear-gradient(to right top, #ff5f6d, #ffc371);
        }
        header {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-bottom: 40px;
        }
        header h2 {
            color: #fff;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.2);
        }
        header img {
            width: 60px;
            height: auto;
        }
        main {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 400px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type=email], input[type=password], input[type=text] {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border: none;
            border-bottom: 2px solid #ccc;
            background-color: transparent;
            transition: border-color 0.3s;
        }
        input[type=email]:focus, input[type=password]:focus, input[type=text]:focus {
            outline: none;
            border-bottom-color: #ff5f6d;
        }
        input[type=submit] {
            background-color: #ff5f6d;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type=submit]:hover {
            background-color: #ff3b5d;
        }
        a {
            color: #ff5f6d;
            text-decoration: none;
            text-align: center;
            display: block;
            margin-top: 20px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h2>AccordEnergie</h2>
        <img src=\"style/logo.png\" alt=\"Logo\">
    </header>
    <main>
        <h1>Créer un compte</h1>
        <form action=\"\" method=\"post\">
            <input
                type=\"email\"
                id=\"email\"
                name=\"email\"
                placeholder=\"Entrer l'email\"
                required
            />
            <input
                type=\"password\"
                id=\"password\"
                name=\"password\"
                placeholder=\"Entrer le mot de passe\"
                required
            />
            <input
                type=\"password\"
                id=\"password_cfg\"
                name=\"password_cfg\"
                placeholder=\"Confirmer le mot de passe\"
                required
            />
            <input
                type=\"text\"
                id=\"last_name\"
                name=\"last_name\"
                placeholder=\"Nom de famille\"
                required
            />
            <input
                type=\"text\"
                id=\"first_name\"
                name=\"first_name\"
                placeholder=\"Prénom\"
                required
            />
            <input
                type=\"text\"
                id=\"postal_nb\"
                name=\"postal_nb\"
                placeholder=\"Code Postal\"
                required
            />
            <!-- Ajout du sélecteur de rôle pour les administrateurs -->
            <!-- À afficher uniquement si l'utilisateur actuel est un admin -->
            <div>
                <label for=\"role\">Rôle :</label>
                <select id=\"role\" name=\"role\">
                    <option value=\"client\">Client</option>
                    <option value=\"intervenant\">Intervenant</option>
                    <option value=\"standardiste\">Standardiste</option>
                    <option value=\"admin\">Admin</option>
                </select>
            </div>
            <div>
                <input type=\"submit\" name=\"send\" value=\"Créer\" />
            </div>
        </form>
        <p>
            <a href=\"index.php\">Se connecter ?</a>
        </p>
    </main>
</body>
</html>";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "register.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\"/>
    <title>AccordEnergie</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f0f0;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 90vh;
            background-image: linear-gradient(to right top, #ff5f6d, #ffc371);
        }
        header {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-bottom: 40px;
        }
        header h2 {
            color: #fff;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.2);
        }
        header img {
            width: 60px;
            height: auto;
        }
        main {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 400px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type=email], input[type=password], input[type=text] {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border: none;
            border-bottom: 2px solid #ccc;
            background-color: transparent;
            transition: border-color 0.3s;
        }
        input[type=email]:focus, input[type=password]:focus, input[type=text]:focus {
            outline: none;
            border-bottom-color: #ff5f6d;
        }
        input[type=submit] {
            background-color: #ff5f6d;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type=submit]:hover {
            background-color: #ff3b5d;
        }
        a {
            color: #ff5f6d;
            text-decoration: none;
            text-align: center;
            display: block;
            margin-top: 20px;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h2>AccordEnergie</h2>
        <img src=\"style/logo.png\" alt=\"Logo\">
    </header>
    <main>
        <h1>Créer un compte</h1>
        <form action=\"\" method=\"post\">
            <input
                type=\"email\"
                id=\"email\"
                name=\"email\"
                placeholder=\"Entrer l'email\"
                required
            />
            <input
                type=\"password\"
                id=\"password\"
                name=\"password\"
                placeholder=\"Entrer le mot de passe\"
                required
            />
            <input
                type=\"password\"
                id=\"password_cfg\"
                name=\"password_cfg\"
                placeholder=\"Confirmer le mot de passe\"
                required
            />
            <input
                type=\"text\"
                id=\"last_name\"
                name=\"last_name\"
                placeholder=\"Nom de famille\"
                required
            />
            <input
                type=\"text\"
                id=\"first_name\"
                name=\"first_name\"
                placeholder=\"Prénom\"
                required
            />
            <input
                type=\"text\"
                id=\"postal_nb\"
                name=\"postal_nb\"
                placeholder=\"Code Postal\"
                required
            />
            <!-- Ajout du sélecteur de rôle pour les administrateurs -->
            <!-- À afficher uniquement si l'utilisateur actuel est un admin -->
            <div>
                <label for=\"role\">Rôle :</label>
                <select id=\"role\" name=\"role\">
                    <option value=\"client\">Client</option>
                    <option value=\"intervenant\">Intervenant</option>
                    <option value=\"standardiste\">Standardiste</option>
                    <option value=\"admin\">Admin</option>
                </select>
            </div>
            <div>
                <input type=\"submit\" name=\"send\" value=\"Créer\" />
            </div>
        </form>
        <p>
            <a href=\"index.php\">Se connecter ?</a>
        </p>
    </main>
</body>
</html>", "register.html.twig", "/var/www/templates/register.html.twig");
    }
}
