<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html.twig */
class __TwigTemplate_e4b1419f7f442d55e4cbd9990abc33c1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\"/>
    <title>AccordEnergie</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f0f0;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 90vh;
            background-image: linear-gradient(to right top, #ff5f6d, #ffc371);
        }

        header {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-bottom: 40px;
        }

        header h2 {
            color: #fff;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.2);
        }

        header img {
            width: 60px;
            height: auto;
        }

        main {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 400px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type=email], input[type=password] {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border: none;
            border-bottom: 2px solid #ccc;
            background-color: transparent;
            transition: border-color 0.3s;
        }

        input[type=email]:focus, input[type=password]:focus {
            outline: none;
            border-bottom-color: #ff5f6d;
        }

        input[type=submit] {
            background-color: #ff5f6d;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type=submit]:hover {
            background-color: #ff3b5d;
        }

        a {
            color: #ff5f6d;
            text-decoration: none;
            text-align: center;
            display: block;
            margin-top: 20px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h2>AccordEnergie</h2>
        <img src=\"style/logo.png\" alt=\"Logo\">
    </header>
    <main>
        <h1>Connexion</h1>

        ";
        // line 100
        if (($context["msg"] ?? null)) {
            // line 101
            echo "            <div>";
            echo twig_escape_filter($this->env, ($context["msg"] ?? null), "html", null, true);
            echo "</div>
        ";
        }
        // line 103
        echo "
        <form action=\"\" method=\"post\">
            <input 
                type=\"email\"
                id=\"email\"
                name=\"email\"
                placeholder=\"Entrer l'email\"
                required
            />

            <input
                type=\"password\"
                id=\"password\"
                name=\"password\"
                placeholder=\"Entrer le mot de passe\"
                required
            />

            <input type=\"submit\" name=\"send\" value=\"Se Connecter\" />
        </form>

        <p>
            <a href=\"register.php\">Pas encore de compte ?</a>
        </p>
    </main>
</body>
</html>
";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  146 => 103,  140 => 101,  138 => 100,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\"/>
    <title>AccordEnergie</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f0f0;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 90vh;
            background-image: linear-gradient(to right top, #ff5f6d, #ffc371);
        }

        header {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-bottom: 40px;
        }

        header h2 {
            color: #fff;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.2);
        }

        header img {
            width: 60px;
            height: auto;
        }

        main {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 400px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type=email], input[type=password] {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border: none;
            border-bottom: 2px solid #ccc;
            background-color: transparent;
            transition: border-color 0.3s;
        }

        input[type=email]:focus, input[type=password]:focus {
            outline: none;
            border-bottom-color: #ff5f6d;
        }

        input[type=submit] {
            background-color: #ff5f6d;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type=submit]:hover {
            background-color: #ff3b5d;
        }

        a {
            color: #ff5f6d;
            text-decoration: none;
            text-align: center;
            display: block;
            margin-top: 20px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h2>AccordEnergie</h2>
        <img src=\"style/logo.png\" alt=\"Logo\">
    </header>
    <main>
        <h1>Connexion</h1>

        {% if msg %}
            <div>{{msg}}</div>
        {% endif %}

        <form action=\"\" method=\"post\">
            <input 
                type=\"email\"
                id=\"email\"
                name=\"email\"
                placeholder=\"Entrer l'email\"
                required
            />

            <input
                type=\"password\"
                id=\"password\"
                name=\"password\"
                placeholder=\"Entrer le mot de passe\"
                required
            />

            <input type=\"submit\" name=\"send\" value=\"Se Connecter\" />
        </form>

        <p>
            <a href=\"register.php\">Pas encore de compte ?</a>
        </p>
    </main>
</body>
</html>
", "index.html.twig", "/var/www/templates/index.html.twig");
    }
}
