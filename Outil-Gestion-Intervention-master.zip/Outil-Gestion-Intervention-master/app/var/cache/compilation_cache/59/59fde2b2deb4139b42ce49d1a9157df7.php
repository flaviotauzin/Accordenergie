<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_e4ccdb26ba60eb23940543c18b185a2a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Accord Energie | ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <link href=\"https://fonts.googleapis.com/css?family=Raleway\" rel=\"stylesheet\">
    <!-- ... Vos autres liens CSS ... -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
    font-family: 'Raleway', sans-serif;
    height: 100vh;
            background-image: linear-gradient(to right top, #ff5f6d, #ffc371);
}


        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: rgba(0, 0, 0, 0.6); /* Semi-transparent background */
            padding: 10px 20px;
        }

        .company-name {
            font-size: 24px;
            color: white;
        }

        .nav-links {
            list-style-type: none;
            display: flex;
            gap: 20px;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            padding: 5px 10px;
            border-bottom: 2px solid transparent;
            transition: border-bottom-color 0.3s;
        }

        .nav-links li a:hover {
            border-bottom-color: white;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }


        .topbar {
            width: 100%;
            background-color: #333;
            color: white;
            padding: 30px 20px;
            display: flex;
            justify-content: center; /* Centre les éléments de la barre supérieure */
            align-items: center;
        }

        .company-name {
            display: flex;
            align-items: center; /* Centre le texte et le logo verticalement */
            gap: 10px; /* Espacement entre le logo et le nom */
        }

        .company-name img {
            height: 50px; /* Taille du logo */
        }

        /* ... */

        .openbtn {
            font-size: 30px;
            cursor: pointer;
            background-color: #333;
            color: white;
            padding: 10px 15px;
            border: none;
            position: absolute;
            left: 20px; /* Positionner le bouton à gauche */
            top: 20px; /* Positionner le bouton en haut */
        }

        .sidebar {
            height: 100vh;
            width: 0;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #111;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
            z-index: 1000; /* Assure que la barre latérale est au-dessus du contenu principal */
        }

        .sidebar a {
            padding: 10px;
            text-decoration: none;
            font-size: 20px;
            color: white;
            display: block;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background-color: #444;
        }

        .sidebar .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        /* ... */
    </style>
</head>

<body>
    <!-- Bouton pour ouvrir la barre latérale -->
    <div class=\"openbtn\" onclick=\"openNav()\">☰</div>

    <!-- Barre latérale -->
    <div id=\"mySidebar\" class=\"sidebar\">
        <a href=\"javascript:void(0)\" class=\"closebtn\" onclick=\"closeNav()\">×</a>
        <!-- Vos liens de barre latérale ici -->
        <a href=\"#\">Link 1</a>
        <a href=\"#\">Link 2</a>
        <a href=\"#\">Link 3</a>
    </div>

    <!-- Barre supérieure -->
    <div class=\"topbar\">
        <div class=\"company-name\">
            <img src=\"style/logo.png\" alt=\"Logo\" />
            Accordenergie
        </div>
    </div>

    <!-- Contenu principal -->
    <div class=\"main\">
        ";
        // line 174
        $this->displayBlock('body', $context, $blocks);
        // line 175
        echo "    </div>

    <script>
        function openNav() {
            document.getElementById(\"mySidebar\").style.width = \"250px\";
        }

        function closeNav() {
            document.getElementById(\"mySidebar\").style.width = \"0\";
        }
    </script>
</body>
</html>





";
    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 174
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "base.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  247 => 174,  241 => 6,  219 => 175,  217 => 174,  46 => 6,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Accord Energie | {% block title %}{% endblock %}</title>
    <link href=\"https://fonts.googleapis.com/css?family=Raleway\" rel=\"stylesheet\">
    <!-- ... Vos autres liens CSS ... -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
    font-family: 'Raleway', sans-serif;
    height: 100vh;
            background-image: linear-gradient(to right top, #ff5f6d, #ffc371);
}


        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: rgba(0, 0, 0, 0.6); /* Semi-transparent background */
            padding: 10px 20px;
        }

        .company-name {
            font-size: 24px;
            color: white;
        }

        .nav-links {
            list-style-type: none;
            display: flex;
            gap: 20px;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            padding: 5px 10px;
            border-bottom: 2px solid transparent;
            transition: border-bottom-color 0.3s;
        }

        .nav-links li a:hover {
            border-bottom-color: white;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }


        .topbar {
            width: 100%;
            background-color: #333;
            color: white;
            padding: 30px 20px;
            display: flex;
            justify-content: center; /* Centre les éléments de la barre supérieure */
            align-items: center;
        }

        .company-name {
            display: flex;
            align-items: center; /* Centre le texte et le logo verticalement */
            gap: 10px; /* Espacement entre le logo et le nom */
        }

        .company-name img {
            height: 50px; /* Taille du logo */
        }

        /* ... */

        .openbtn {
            font-size: 30px;
            cursor: pointer;
            background-color: #333;
            color: white;
            padding: 10px 15px;
            border: none;
            position: absolute;
            left: 20px; /* Positionner le bouton à gauche */
            top: 20px; /* Positionner le bouton en haut */
        }

        .sidebar {
            height: 100vh;
            width: 0;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #111;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
            z-index: 1000; /* Assure que la barre latérale est au-dessus du contenu principal */
        }

        .sidebar a {
            padding: 10px;
            text-decoration: none;
            font-size: 20px;
            color: white;
            display: block;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background-color: #444;
        }

        .sidebar .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        /* ... */
    </style>
</head>

<body>
    <!-- Bouton pour ouvrir la barre latérale -->
    <div class=\"openbtn\" onclick=\"openNav()\">☰</div>

    <!-- Barre latérale -->
    <div id=\"mySidebar\" class=\"sidebar\">
        <a href=\"javascript:void(0)\" class=\"closebtn\" onclick=\"closeNav()\">×</a>
        <!-- Vos liens de barre latérale ici -->
        <a href=\"#\">Link 1</a>
        <a href=\"#\">Link 2</a>
        <a href=\"#\">Link 3</a>
    </div>

    <!-- Barre supérieure -->
    <div class=\"topbar\">
        <div class=\"company-name\">
            <img src=\"style/logo.png\" alt=\"Logo\" />
            Accordenergie
        </div>
    </div>

    <!-- Contenu principal -->
    <div class=\"main\">
        {% block body %}{% endblock %}
    </div>

    <script>
        function openNav() {
            document.getElementById(\"mySidebar\").style.width = \"250px\";
        }

        function closeNav() {
            document.getElementById(\"mySidebar\").style.width = \"0\";
        }
    </script>
</body>
</html>





", "base.html.twig", "/var/www/templates/base.html.twig");
    }
}
